

import java.util.*;
public class Square
{
    public static void main()
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Input a number for finding it's square ...");
       double a=sc.nextDouble();
       double ans=a*a;
       System.out.println("Calculating square.....");
       System.out.println("        ");
       System.out.println("Square of two numbers = "+ans);
    }
}
