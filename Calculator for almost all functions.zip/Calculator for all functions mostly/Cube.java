
import java.util.*;
public class Cube
{
    public static void main()
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Input a number for finding it's cube ...");
       double a=sc.nextDouble();
       double ans=a*a*a;
       System.out.println("Calculating cube.....");
       System.out.println("        ");
       System.out.println("Cube of two numbers = "+ans);
    }
}
