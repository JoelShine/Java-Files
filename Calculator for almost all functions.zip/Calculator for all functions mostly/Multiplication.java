
import java.util.*;
public class Multiplication
{
    public static void main()
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Input two numbers for finding the product...");
       double a=sc.nextDouble();
       double b=sc.nextDouble();
       double ans=a*b;
       System.out.println("Calculating product.....");
       System.out.println("        ");
       System.out.println("Product of two numbers = "+ans);
    }
}
