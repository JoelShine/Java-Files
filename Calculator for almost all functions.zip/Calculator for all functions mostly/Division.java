
import java.util.*;
public class Division
{
    public static void main()
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Input two numbers for finding the quotient...");
       double a=sc.nextDouble();
       double b=sc.nextDouble();
       double ans=a/b;
       System.out.println("Calculating quotient.....");
       System.out.println("        ");
       System.out.println("Quotient of two numbers = "+ans);
    }
}
