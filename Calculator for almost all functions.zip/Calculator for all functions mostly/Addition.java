
import java.util.*;
public class Addition
{
    public static void main()
    {
       Scanner sc=new Scanner(System.in);
       System.out.println("Input two numbers for finding the sum...");
       double a=sc.nextDouble();
       double b=sc.nextDouble();
       double ans=a+b;
       System.out.println("Calculating sum.....");
       System.out.println("        ");
       System.out.println("Sum of two numbers = "+ans);
    }
}
